import { NgModule } from "@angular/core";
import { AcceptHireComponent } from "./accept.hire.component";
import { AcceptHireRoutingModule } from "./accept.hire.routing.module";
import { AcceptHireHeaderComponent } from "./accept.hire.header.component";
import { HireComponent  } from "./hire/hire.component";
import { PaymentTermsComponent} from "./payment-terms/payment.terms.component";
import { PaymentStatusComponent } from "./payment-status/payment.status.component";
import { PaymentRecieptComponent } from "./payment-reciept/payment.reciept.component";
import { SharedModule } from "shared/shared.module";
import { AcceptHire } from "./AcceptHire.service"
import { CommonModule } from '@angular/common';  
import { PrivatePolicyDialogService } from '../signup/private-policy-dialog/dialog.service';
@NgModule({
    imports: [
        [CommonModule],
        AcceptHireRoutingModule,
        SharedModule,
      
    ],
    declarations: [
        AcceptHireComponent,
        AcceptHireHeaderComponent,
        HireComponent,
        PaymentTermsComponent,
        PaymentStatusComponent,
        PaymentRecieptComponent
 
    ],
    exports: [
        AcceptHireComponent
    ],
    providers: [
        AcceptHire,
        PrivatePolicyDialogService
    ]
})
export class AcceptHireModule { }
