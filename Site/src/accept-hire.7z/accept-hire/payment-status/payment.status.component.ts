
import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from 'auth/auth.service';


@Component({
    selector: 'ij-payment-status',
    templateUrl: './payment.status.component.html',
    styleUrls: ['./styles.less']
})
export class PaymentStatusComponent  implements OnInit {
    constructor(
 
    ) {
       
    }

    ngOnInit() {
    
    }



   
}
