import { Injectable } from '@angular/core';
import { HttpClient, HttpParams, HttpHeaders } from '@angular/common/http';
import { ProfileStatusTypes } from 'shared/services/ProfileStatusTypes';
import { Observable } from 'rxjs/Observable';

import { ISiteApiResponse, SiteApiResponseUtilities } from 'shared/services/SiteApiResponse';
import * as httputils from 'shared/angular/http';
import { environment } from 'environments/environment';
import { HireProfileRequestDisplay } from '../accept-hire/models'
import 'rxjs/add/operator/catch';

@Injectable()
export class AcceptHire {
    private respUtils = new SiteApiResponseUtilities();

    constructor (
        private http: HttpClient
    ) { }

   
    getHireDetails(id: string) {
        const url = environment.endpoints.profile.freelancer.hireContactDetails(id);
     return this.http
            .get(url)
            .map(data => data as HireProfileRequestDisplay[]);
    }

    acceptHireDetails(id:number,status:string)
    {
        const url = environment.endpoints.profile.freelancer.acceptHireDetails(id,status);
          debugger;
        return this.http
        .post(url,null)
        .map(r=>true);
    }
}
