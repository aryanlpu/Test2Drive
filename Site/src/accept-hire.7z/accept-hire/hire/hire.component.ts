import { Component,ElementRef, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from 'auth/auth.service';
import { AcceptHire } from './../AcceptHire.service'
import { HireProfileRequestDisplay,HireProfileDialog,UserProfileModel } from '../models'
import { DialogHeaderService } from '../../shared/dialogs/header/dialog-header.service'
import { DatePipe } from '@angular/common';
import { CurrencyPipe } from '@angular/common'
import { ISubscription } from 'rxjs/Subscription';
import { BaseDialogComponent } from '../../shared/dialogs/BaseDialogComponent'
import { NotificationsService } from 'angular2-notifications';
import { DialogHeader } from '../../shared/dialogs/header/DialogHeader'
import { environment } from 'environments/environment';
import { PrivatePolicyDialogService } from '../../signup/private-policy-dialog/dialog.service';

@Component({
    selector: 'ij-hire',
    templateUrl: './hire.component.html',
    styleUrls: ['./styles.less']
})
export class HireComponent    implements OnInit  {
    modelData:HireProfileRequestDisplay[];
    private model:UserProfileModel;
    private modelcontractee:UserProfileModel;
    private dialogSub: ISubscription;
    private headerSub: ISubscription;
    public IsRemoveButton: boolean = false;
    public acceptTerms: boolean = false;
    constructor(
     private acceptHire:AcceptHire,
    
     private authservice:AuthService,
     private headerSvc: DialogHeaderService,
     private notificationSvc: NotificationsService,
     private privatePolicySvc: PrivatePolicyDialogService,

     ) {
       
    }

  
    ngOnInit() {
        this.acceptHire.getHireDetails(this.authservice.profileSysId).subscribe(responsedata => {
            this.modelData = responsedata
        });

    }

    onBeforeSend(event) {
        if (event.xhr) {
            event.xhr.setRequestHeader('Authorization', this.authservice.bearer);
        }
    }


    AcceptHire(hireId:number)
    {
        this.acceptHire.acceptHireDetails(hireId,"AcceptedRate").subscribe(r=>{ 
            if (this.notificationSvc) {
            this.notificationSvc.success("Success", "Your Response has been sent.");
        };
    })  
    }


    getImageUrl(imageUrl: string){
          
        if (imageUrl) {
            return environment.site.imageUrl(imageUrl);
        }
        else {
            return '../assets/images/avatars/avatar-lg.png';
        }
    }


 
    
    showPrivatePolicyDialog() {
        this.privatePolicySvc.showDialog();
    }
   
}
