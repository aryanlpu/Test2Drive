
import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from 'auth/auth.service';


@Component({
    selector: 'ij-payment-reciept',
    templateUrl: './payment.reciept.component.html',
    styleUrls: ['./styles.less']
})
export class PaymentRecieptComponent  implements OnInit {
    constructor(
 
    ) {
       
    }

    ngOnInit() {
    
    }



   
}
