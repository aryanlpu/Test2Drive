
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AuthGuard } from '../auth/auth.guard';
import { AcceptHireComponent } from "./accept.hire.component";
import { AcceptHireHeaderComponent } from "./accept.hire.header.component";
import { HireComponent } from "./hire/hire.component";
import { PaymentTermsComponent } from "./payment-terms/payment.terms.component";
import { PaymentStatusComponent } from "./payment-status/payment.status.component";
import { PaymentRecieptComponent } from "./payment-reciept/payment.reciept.component";


  const routes: Routes = [
    //   {
    //     path: '',
    //     component: AcceptHireComponent
    //   },
      {
        path: '',
        component: AcceptHireComponent,
        children: [{
          path: '',
          children: [
            { path: '', redirectTo: 'All', pathMatch: 'full' },
            { path: 'All', component: HireComponent },
            { path: 'payment-terms', component: PaymentTermsComponent },
            { path: 'payment-status', component: PaymentStatusComponent },
            { path: 'payment-reciept', component: PaymentRecieptComponent },
          ]  
        }]
      }
    ];

@NgModule({
  imports: [ RouterModule.forChild(routes) ],
  exports: [ RouterModule ],
  providers: []
})
export class AcceptHireRoutingModule {}
