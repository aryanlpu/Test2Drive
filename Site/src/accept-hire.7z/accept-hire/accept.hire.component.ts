
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from 'auth/auth.service';
import { AcceptHireHeaderComponent } from './accept.hire.header.component';
import { SiteSubHeaderComponent } from 'shared/components/site-subheader/site-subheader.component';
@Component({
  selector: 'ij-accept-hire',
  templateUrl: './accept.hire.component.html',
  styleUrls: ['./styles.less']
})
export class AcceptHireComponent implements OnInit {

  constructor(
  ) {
   
  }

  ngOnInit() {

  }

 


}
