import { Component, OnInit, ViewChild } from '@angular/core';
import { SiteHeaderComponent } from 'shared/components/site-header/site-header.component';

@Component({
    selector: 'ij-accept-hire-header',
    templateUrl: './accept.hire.header.component.html'
})
export class AcceptHireHeaderComponent {
    @ViewChild("siteHeader") siteHeader: SiteHeaderComponent;
    constructor() { }
}
