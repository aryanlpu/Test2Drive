;
import { Component,ElementRef, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from 'auth/auth.service';
import { AcceptHire } from './../AcceptHire.service'
import { HireProfileRequestDisplay,HireProfileDialog,UserProfileModel } from '../models'
import { DialogHeaderService } from '../../shared/dialogs/header/dialog-header.service'
import { DatePipe } from '@angular/common';
import { CurrencyPipe } from '@angular/common'
import { ISubscription } from 'rxjs/Subscription';
import { BaseDialogComponent } from '../../shared/dialogs/BaseDialogComponent'
import { NotificationsService } from 'angular2-notifications';
import { DialogHeader } from '../../shared/dialogs/header/DialogHeader'
import { environment } from 'environments/environment';

@Component({
    selector: 'ij-payment-terms',
    templateUrl: './payment.terms.component.html',
    styleUrls: ['./styles.less']
})
export class PaymentTermsComponent  implements OnInit {
    modelData:HireProfileRequestDisplay[];
    private model:UserProfileModel;
    private modelcontractee:UserProfileModel;
    private dialogSub: ISubscription;
    private headerSub: ISubscription;
    public IsRemoveButton: boolean = false;
    constructor(
     private acceptHire:AcceptHire,
     private authservice:AuthService,
     private headerSvc: DialogHeaderService,
     private notificationSvc: NotificationsService
     ) {
     }

  
    ngOnInit() {
        this.acceptHire.getHireDetails(this.authservice.profileSysId).subscribe(responsedata => {
            this.modelData = responsedata
         
        });
    
    }

    getImageUrl(imageUrl: string){
          
        if (imageUrl) {
            return environment.site.imageUrl(imageUrl);
        }
        else {
            return '../assets/images/avatars/avatar-lg.png';
        }
    }



    acceptJob(hireId:number)
    {
        this.acceptHire.acceptHireDetails(hireId,"AcceptedJob").subscribe(r=>{ 
            if (this.notificationSvc) {
            this.notificationSvc.success("Success", "Your Response has been sent.");
        };
    })  
    }

   
}
